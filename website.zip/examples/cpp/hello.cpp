#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    cout << "Добро пожаловать в C++!" << endl;
    cout << "Этот код компилируется и выполняется на сервере!" << endl;
    return 0;
}