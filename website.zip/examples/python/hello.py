print("Hello, World!")
print("Добро пожаловать в Python!")
print("Этот код выполняется на сервере!")