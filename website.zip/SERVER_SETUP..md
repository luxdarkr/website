# Настройка Python сервера

## Установка зависимостей

```bash
pip install flask flask-cors